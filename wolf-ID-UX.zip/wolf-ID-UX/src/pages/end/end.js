import React, { Component,useState } from "react";
import './end.css'

function EndContainer() {


    return (
      <div className="container">
        <div className="title">
        <h1>Thank you for completing the study! </h1>
      </div>
      </div>
      );
}

export default EndContainer;